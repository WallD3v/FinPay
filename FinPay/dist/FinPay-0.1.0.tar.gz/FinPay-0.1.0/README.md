Made by WD(WallDev)

Example file: [HERE](https://raw.githubusercontent.com/WallD3v/FinPay/main/examples/example.py/)
Pypi page: [HERE](https://pypi.org/project/FinPay/)

My telegram: [CLICK](https://t.me/wdp_owner)