from setuptools import setup
setup(name='FinPay',
      version='0.1.0',
      description='A module to work with api API',
      url="https://github.com/WallD3v/FinPay",
      author='WallDev',
      author_email='walldevnewthon@gmail.com',
      license='MIT',
      packages=['FinPay'],
      zip_safe=False) 
      